# StudyMate AI — Setup Guide for Beginners

StudyMate AI has **three separate programs** that all need to be running at the same time,
each in its own terminal window:

| # | Folder         | What it does                                              | Runs on              |
|---|----------------|------------------------------------------------------------|----------------------|
| 1 | `ai-service/`  | Reads PDFs, creates embeddings, searches them (Python)      | http://localhost:8001 |
| 2 | `backend/`     | Login/signup, database, talks to Claude AI (Node.js)        | http://localhost:5000 |
| 3 | `frontend/`    | The website you see and click on (React)                    | http://localhost:5173 |

Think of it like a restaurant: `frontend` is the dining room, `backend` is the waiter taking
orders and remembering them, and `ai-service` is the kitchen that actually reads your PDFs.
You need all three "open" for the restaurant to work.

You will open **3 terminals** and leave all 3 running. Don't close them while using the app.

---

## Part 0 — Install these first (one-time setup)

Install each of these, restart your computer or terminal afterwards, then check with the
"verify" command shown. If a verify command gives an error like "not recognized", the
installer likely didn't add it to your PATH — reinstall and make sure any "Add to PATH"
checkbox is ticked.

| Tool | Download link | Verify with |
|---|---|---|
| **Python 3.11** (not 3.12/3.13/3.14 — see note below) | https://www.python.org/downloads/release/python-3119/ | `python --version` or `py -3.11 --version` |
| **Node.js 20 LTS** | https://nodejs.org | `node --version` and `npm --version` |
| **MongoDB Community Server** | https://www.mongodb.com/try/download/community | `mongod --version` |
| **Git** (optional, only if you cloned this from a repo) | https://git-scm.com | `git --version` |
| **VS Code** | https://code.visualstudio.com | — |

> **Why Python 3.11 specifically?** The AI service depends on packages (`sentence-transformers`,
> `chromadb`) that don't yet ship ready-made installers for the newest Python versions. Using
> 3.11 avoids compiler errors during installation. It's fine to have multiple Python versions
> installed side by side — installing 3.11 will not remove any other version you have.

> **Don't want to install MongoDB locally?** Create a free cluster at
> https://www.mongodb.com/cloud/atlas instead, and use the connection string it gives you
> as `MONGO_URI` in Part 3 below.

You will also need an **Anthropic API key** for Claude to generate answers:
1. Go to https://console.anthropic.com
2. Sign up / log in
3. Go to **API Keys** → **Create Key**
4. Copy the key (starts with `sk-ant-...`) — you'll paste it into `.env` in Part 4.

---

## Part 1 — Open the project in VS Code

1. Unzip `studymate-ai.zip` somewhere easy to find, e.g. `C:\Projects\studymate-ai` or `~/Projects/studymate-ai`.
2. Open VS Code.
3. **File → Open Folder** → select the unzipped `studymate-ai` folder.
4. Open a terminal inside VS Code: **Terminal → New Terminal** (or `` Ctrl+` ``).

You'll use this terminal panel for everything below — click the `+` icon in the terminal
panel to open additional tabs (you'll need 3 total, one per service).

---

## Part 2 — Start MongoDB

If you installed MongoDB locally, start it once (leave it running in the background):

**Windows** (MongoDB usually installs as a service and starts automatically — check with):
```powershell
net start MongoDB
```

**Mac** (if installed via Homebrew):
```bash
brew services start mongodb-community
```

**Linux:**
```bash
sudo systemctl start mongod
```

If you're using MongoDB Atlas (the cloud option) instead, skip this step entirely.

---

## Part 3 — Set up the AI service (Terminal 1)

This service handles reading your PDFs and searching them.

```bash
cd ai-service
```

**Create a virtual environment using Python 3.11 specifically:**

Windows:
```powershell
py -3.11 -m venv venv
venv\Scripts\activate
```

Mac/Linux:
```bash
python3.11 -m venv venv
source venv/bin/activate
```

> You'll know it worked if your terminal prompt now starts with `(venv)`.

**Install the dependencies:**
```bash
pip install --upgrade pip
pip install -r requirements.txt
```
This step downloads a few hundred MB (it includes PyTorch for the AI model) — it can take
several minutes on the first run. That's normal.

**Start the service:**
```bash
uvicorn main:app --reload --port 8001
```

You should see something like `Uvicorn running on http://127.0.0.1:8001`. Leave this
terminal open and running.

**Sanity check:** open http://localhost:8001/health in your browser — you should see
`{"status":"ok","service":"studymate-ai-processing"}`.

---

## Part 4 — Set up the backend (Terminal 2)

Open a **new** terminal tab (click `+` in VS Code's terminal panel), then:

```bash
cd backend
```

**Create your environment file:**

Windows:
```powershell
copy .env.example .env
```

Mac/Linux:
```bash
cp .env.example .env
```

**Open the new `.env` file** (in VS Code's file explorer, under `backend/.env`) and fill in:

```env
MONGO_URI=mongodb://localhost:27017/studymate_ai
JWT_SECRET=any_long_random_sentence_you_make_up_here
ANTHROPIC_API_KEY=sk-ant-your-actual-key-from-console.anthropic.com
```

- `MONGO_URI` — leave as-is if using local MongoDB; paste your Atlas connection string instead if using the cloud option.
- `JWT_SECRET` — just type a long random string, e.g. `banana-truck-purple-52-orbit`. It's used to sign login tokens.
- `ANTHROPIC_API_KEY` — paste the key from Part 0.

**Install dependencies and start the server:**
```bash
npm install
npm run dev
```

You should see `[MongoDB] Connected` and `[StudyMate AI] Backend running on port 5000`.
Leave this terminal open too.

**Sanity check:** open http://localhost:5000/api/health — you should see
`{"status":"ok","service":"studymate-ai-backend"}`.

---

## Part 5 — Set up the frontend (Terminal 3)

Open a **third** terminal tab, then:

```bash
cd frontend
```

**Create your environment file:**

Windows:
```powershell
copy .env.example .env
```

Mac/Linux:
```bash
cp .env.example .env
```

The default value inside (`VITE_API_URL=http://localhost:5000/api`) is already correct —
no editing needed unless you changed the backend's port.

**Install dependencies and start it:**
```bash
npm install
npm run dev
```

You should see something like:
```
  VITE ready
  ➜  Local:   http://localhost:5173/
```

---

## Part 6 — Use the app

1. Open http://localhost:5173 in your browser.
2. Click **Create an account**, sign up with any name/email/password.
3. On the Dashboard, drag a PDF (lecture notes, a textbook chapter) into the upload box.
4. Wait for its status pill to change from **Processing** to **Ready** (a few seconds to
   a minute depending on PDF length).
5. Click **Ask** on that document, or go to **Study Chat**, pick it from the dropdown, and
   ask a question about it.

If all three terminals are still running (uvicorn, backend's `npm run dev`, frontend's
`npm run dev`) and show no red error text, the app is fully live.

---

## Every time after the first (you don't need to redo Part 3/4/5's installs)

Once set up, starting the app again is just 3 commands in 3 terminals:

```bash
# Terminal 1
cd ai-service
venv\Scripts\activate       # Mac/Linux: source venv/bin/activate
uvicorn main:app --reload --port 8001

# Terminal 2
cd backend
npm run dev

# Terminal 3
cd frontend
npm run dev
```

(Make sure MongoDB is running too, if it doesn't start automatically on your machine.)

---

## Troubleshooting

**"link.exe not found" / Rust compiler errors when running `pip install -r requirements.txt`**
You're on a Python version newer than 3.11 (check with `python --version` inside the venv).
Delete the `venv` folder, and redo Part 3 making sure you used `py -3.11` (Windows) or
`python3.11` (Mac/Linux) to create it, not plain `python`.

**"MongoServerError" or backend can't connect to MongoDB**
MongoDB isn't running. Revisit Part 2. If using Atlas, double check your `MONGO_URI` in
`backend/.env`, and that your current IP is allowed in Atlas's Network Access settings.

**Upload gets stuck on "Processing" then shows "Failed"**
Check Terminal 1 (the `ai-service` one) for an error message — most often the PDF is a
scanned image with no selectable text, which `pypdf` can't extract. Try a text-based PDF.

**"401 Unauthorized" errors, or you get logged out immediately after logging in**
Usually means the backend restarted and its `JWT_SECRET` changed, invalidating old tokens.
Just log in again.

**Claude answers say something went wrong / 502 errors from `/api/chat/ask`**
Double-check `ANTHROPIC_API_KEY` in `backend/.env` is correct and has no extra spaces, and
that your Anthropic account has available credits.

**Port already in use (`EADDRINUSE`)**
Something else on your machine is already using that port. Either close that program, or
change the port: for the backend, edit `PORT` in `backend/.env`; for the AI service, run
`uvicorn main:app --reload --port 8002` instead and update `AI_SERVICE_URL` in
`backend/.env` to match; for the frontend, Vite will usually prompt to use the next free
port automatically.

**`npm install` fails**
Confirm Node.js is installed correctly with `node --version` (should be v18 or newer).
Delete the `node_modules` folder and `package-lock.json` in that folder, then run
`npm install` again.

---

## Project structure reference

```
studymate-ai/
├── ai-service/     # Python — PDF text extraction, embeddings, ChromaDB vector search
├── backend/        # Node.js — auth, MongoDB, orchestration, Claude API calls
└── frontend/       # React — the web UI (claymorphic design)
```

Each folder has its own `package.json` / `requirements.txt` — they are independent programs
that talk to each other over HTTP, not one combined app.
